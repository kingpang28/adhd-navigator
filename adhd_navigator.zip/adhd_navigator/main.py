import json
import os
from datetime import datetime
from rich.console import Console
from rich.panel import Panel
# from rich.menu import Menu (Removed unused import causing error)
from rich.prompt import Prompt

# Import our modules
from screening import ADHDScanner
from vitals import VitalsTracker
from clinics import ClinicManager

console = Console()

class ADHDApp:
    def __init__(self):
        self.data_file = "user_data.json"
        self.user_data = self.load_data()
        self.scanner = ADHDScanner()
        self.tracker = VitalsTracker()
        self.clinics = ClinicManager()

    def load_data(self):
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r') as f:
                return json.load(f)
        return {
            "screening": None,
            "vitals": None,
            "last_updated": None
        }

    def save_data(self):
        self.user_data["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(self.data_file, 'w') as f:
            json.dump(self.user_data, f, indent=4)

    def show_dashboard(self):
        console.clear()
        console.print(Panel.fit("[bold green]ADHD Pre-Referral Navigator (UK)[/bold green]", subtitle="v1.0 Professional Edition"))
        
        # Status Summary
        status_text = []
        if self.user_data["screening"]:
            likelihood = self.user_data["screening"]["likelihood"]
            status_text.append(f"• Screening: [bold]{likelihood} Likelihood[/bold]")
        else:
            status_text.append("• Screening: [dim]Not Started[/dim]")
            
        if self.user_data["vitals"]:
            v_status = self.user_data["vitals"]["status"]
            status_text.append(f"• Vitals: [bold]{v_status}[/bold]")
        else:
            status_text.append("• Vitals: [dim]Not Recorded[/dim]")

        console.print(Panel("\n".join(status_text), title="Your Progress"))
        
        console.print("\n[bold]Main Menu:[/bold]")
        console.print("1. Start Clinical Screening (ASRS v1.1)")
        console.print("2. Record Vitals (Medication Readiness)")
        console.print("3. Compare RTC Clinics (Wait Times)")
        console.print("4. View Referral Readiness Report")
        console.print("5. Exit")
        
        choice = Prompt.ask("Choose an option", choices=["1", "2", "3", "4", "5"])
        return choice

    def run(self):
        while True:
            choice = self.show_dashboard()
            
            if choice == "1":
                self.user_data["screening"] = self.scanner.run_screening()
                self.save_data()
                Prompt.ask("\nPress Enter to return to menu")
            elif choice == "2":
                self.user_data["vitals"] = self.tracker.record_vitals()
                self.save_data()
                Prompt.ask("\nPress Enter to return to menu")
            elif choice == "3":
                self.clinics.display_clinics()
                Prompt.ask("\nPress Enter to return to menu")
            elif choice == "4":
                self.generate_report()
            elif choice == "5":
                console.print("[italic]Good luck on your journey. Stay patient![/italic]")
                break

    def generate_report(self):
        console.clear()
        console.print(Panel("[bold]Referral Readiness Report[/bold]", style="blue"))
        
        if not self.user_data["screening"] or not self.user_data["vitals"]:
            console.print("[yellow]Warning: Please complete both screening and vitals for a full report.[/yellow]")
        
        # Logic for readiness
        ready = True
        if not self.user_data["screening"] or self.user_data["screening"]["likelihood"] == "Low":
            ready = False
        if not self.user_data["vitals"] or self.user_data["vitals"]["status"] != "Ready":
            ready = False
            
        if ready:
            console.print("[bold green]✓ STATUS: REFERRAL READY[/bold green]")
            console.print("You have symptoms consistent with ADHD and stable vitals. "
                          "You can now take this data to your GP to request a Right to Choose referral.")
        else:
            console.print("[bold red]STATUS: ACTION REQUIRED[/bold red]")
            console.print("Check your screening likelihood or vitals review notes.")
            
        # Display summary data
        console.print("\n[bold underline]Data Summary for GP:[/bold underline]")
        if self.user_data["screening"]:
            console.print(f"ASRS v1.1 Score: {self.user_data['screening']['score']}/6 (Positive Indicators)")
        if self.user_data["vitals"]:
            v = self.user_data["vitals"]
            console.print(f"Baseline Vitals: {v['systolic']}/{v['diastolic']} mmHg, {v['pulse']} BPM")
            
        Prompt.ask("\nPress Enter to return to menu")

if __name__ == "__main__":
    app = ADHDApp()
    app.run()
