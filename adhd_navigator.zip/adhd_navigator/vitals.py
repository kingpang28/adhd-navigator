from rich.console import Console
from rich.panel import Panel
from rich.prompt import IntPrompt
from rich.table import Table

console = Console()

class VitalsTracker:
    def __init__(self):
        self.bp_threshold_systolic = 140
        self.bp_threshold_diastolic = 90
        self.hr_threshold = 100

    def record_vitals(self):
        console.print(Panel("[bold cyan]Vitals Tracking & Medication Readiness[/bold cyan]\n"
                            "NICE guidelines require a baseline Blood Pressure (BP) and Heart Rate (HR) "
                            "before starting ADHD medication. Tracking these now makes you 'Referral Ready'."))
        
        sys = IntPrompt.ask("Enter Systolic Blood Pressure (top number, e.g., 120)")
        dia = IntPrompt.ask("Enter Diastolic Blood Pressure (bottom number, e.g., 80)")
        hr = IntPrompt.ask("Enter Resting Heart Rate (BPM, e.g., 70)")
        
        status = self.check_readiness(sys, dia, hr)
        
        table = Table(title="Vitals Summary")
        table.add_column("Metric", style="bold")
        table.add_column("Value")
        table.add_column("Status")
        
        table.add_row("Systolic BP", str(sys), "Normal" if sys < self.bp_threshold_systolic else "High")
        table.add_row("Diastolic BP", str(dia), "Normal" if dia < self.bp_threshold_diastolic else "High")
        table.add_row("Heart Rate", str(hr), "Normal" if hr < self.hr_threshold else "High")
        
        console.print(table)
        
        if status == "Ready":
            console.print("[bold green]✓ You are Medication Ready![/bold green] Your vitals are within the standard range for starting assessment.")
        else:
            console.print("[bold yellow]! Clinical Note:[/bold yellow] Your vitals are outside the standard range. "
                          "A GP will need to review these before prescribing stimulants.")
            
        return {"systolic": sys, "diastolic": dia, "pulse": hr, "status": status}

    def check_readiness(self, sys, dia, hr):
        if sys >= self.bp_threshold_systolic or dia >= self.bp_threshold_diastolic or hr >= self.hr_threshold:
            return "Requires Review"
        return "Ready"

if __name__ == "__main__":
    tracker = VitalsTracker()
    tracker.record_vitals()
