# ADHD Pre-Referral Navigator (UK)

Welcome! This Python application is designed to help you navigate the "Right to Choose" (RTC) process for ADHD in the UK. It is built for beginners and follows the **NICE (National Institute for Health and Care Excellence)** guidelines.

## 🌟 Key Features
1.  **Clinical Screening**: Uses the official WHO ASRS v1.1 questionnaire to score your symptoms.
2.  **Vitals Tracking**: Records your Blood Pressure and Heart Rate to ensure you are "Medication Ready" before your appointment.
3.  **Clinic Comparison**: Shows up-to-date wait times (as of Feb 2026) for major UK RTC providers like Psychiatry-UK and ADHD 360.
4.  **Referral Report**: Generates a summary you can show your GP to speed up your referral.

## 🛠️ How to Run (For Beginners)
1.  **Install Python**: Make sure you have Python installed on your computer.
2.  **Install Dependencies**: This app uses the `rich` library for a professional look. Run this command in your terminal:
    ```bash
    pip install rich
    ```
3.  **Run the App**: Open your terminal or command prompt, navigate to the folder, and type:
    ```bash
    python main.py
    ```

## 📋 Why This App?
- **Neutrality**: It doesn't push you to one specific clinic.
- **Guideline-Led**: Most "quizzes" online aren't clinically valid. This one uses the same logic as the specialists.
- **Physical Data**: Doctors need your vitals to prescribe medication. By tracking them now, you save weeks of back-and-forth during titration.

## ⚠️ Disclaimer
This app is a **pre-referral tool**, not a diagnostic tool. A formal diagnosis must be made by a qualified specialist.

---
*Built with care to help you get the support you deserve.*
