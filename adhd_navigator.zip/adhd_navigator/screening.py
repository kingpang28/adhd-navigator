from rich.console import Console
from rich.panel import Panel
from rich.prompt import IntPrompt

console = Console()

class ADHDScanner:
    def __init__(self):
        # ASRS v1.1 Questions
        # Part A (First 6 are most predictive)
        self.questions_part_a = [
            "How often do you have trouble wrapping up the final details of a project, once the challenging parts have been done?",
            "How often do you have difficulty getting things in order when you have to do a task that requires organization?",
            "How often do you have problems remembering appointments or obligations?",
            "When you have a task that requires a lot of thought, how often do you avoid or delay getting started?",
            "How often do you fidget or squirm with your hands or feet when you have to sit down for a long time?",
            "How often do you feel overly active and compelled to do things, as if you were driven by a motor?"
        ]
        
        self.options = {
            1: "Never",
            2: "Rarely",
            3: "Sometimes",
            4: "Often",
            5: "Very Often"
        }

    def run_screening(self):
        console.print(Panel("[bold blue]ADHD Clinical Screening (ASRS v1.1)[/bold blue]\n"
                            "This tool uses the World Health Organization (WHO) Adult ADHD Self-Report Scale.\n"
                            "Please answer honestly based on how you have felt over the last 6 months."))
        
        score_part_a = 0
        
        for i, q in enumerate(self.questions_part_a):
            console.print(f"\n[bold]Q{i+1}: {q}[/bold]")
            for val, text in self.options.items():
                console.print(f"  {val}. {text}")
            
            choice = IntPrompt.ask("Select an option", choices=[str(k) for k in self.options.keys()])
            
            # Scoring logic for ASRS v1.1 Part A
            # For Q1-Q3: 'Sometimes', 'Often', 'Very Often' are positive indicators (choice >= 3)
            # For Q4-Q6: 'Often', 'Very Often' are positive indicators (choice >= 4)
            if i < 3:
                if choice >= 3:
                    score_part_a += 1
            else:
                if choice >= 4:
                    score_part_a += 1
        
        return self.analyze_results(score_part_a)

    def analyze_results(self, score_part_a):
        likelihood = "Low"
        color = "green"
        message = "Your symptoms do not currently align strongly with adult ADHD according to the ASRS v1.1 criteria."

        if score_part_a >= 4:
            likelihood = "High"
            color = "red"
            message = ("Your responses are highly consistent with adult ADHD. "
                       "This warrants further clinical assessment by a specialist.")
        elif score_part_a >= 2:
            likelihood = "Moderate"
            color = "yellow"
            message = "You have some symptoms of ADHD. A formal clinical review is recommended if these impact your daily life."

        result_panel = Panel(
            f"[bold {color}]Likelihood: {likelihood}[/bold {color}]\n\n"
            f"Part A Positive Indicators: {score_part_a}/6\n"
            f"Guideline Note: {message}",
            title="Screening Result",
            border_style=color
        )
        console.print(result_panel)
        return {"score": score_part_a, "likelihood": likelihood}

if __name__ == "__main__":
    scanner = ADHDScanner()
    scanner.run_screening()
