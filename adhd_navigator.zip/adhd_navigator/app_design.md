# ADHD Pre-Referral Navigator - Technical Design

## 1. Application Structure
The app will be a Python-based CLI (Command Line Interface) application, designed for simplicity and "professional" feel using the `rich` library for beautiful terminal output.

### Modules:
- `main.py`: Entry point and main menu.
- `screening.py`: Handles the ASRS v1.1 questionnaire and scoring logic.
- `vitals.py`: Manages blood pressure and heart rate logging.
- `clinics.py`: Data and logic for UK RTC clinic comparison.
- `utils.py`: Formatting helpers and data persistence (JSON-based).

## 2. Data Models (JSON)
We will store user data locally to ensure privacy.
```json
{
  "user_profile": {
    "name": "User",
    "age_group": "adult"
  },
  "screening_results": {
    "score_part_a": 0,
    "score_part_b": 0,
    "likelihood": "High",
    "timestamp": ""
  },
  "vitals": [
    {
      "systolic": 120,
      "diastolic": 80,
      "pulse": 70,
      "timestamp": ""
    }
  ],
  "preferences": {
    "preferred_clinic": null
  }
}
```

## 3. Core Logic
- **Scoring**: ASRS v1.1 Part A (4+ marks = High Likelihood).
- **Vitals Check**: Alert if BP > 140/90 or Pulse > 100 bpm (NICE baseline concerns).
- **Clinic Comparison**: Dynamic list based on research findings.

## 4. User Experience (UX)
- Step-by-step wizard for beginners.
- Clear explanations of *why* we ask for vitals (Medication Readiness).
- "Referral Ready" status indicator.
