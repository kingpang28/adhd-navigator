from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()

class ClinicManager:
    def __init__(self):
        # Data based on research findings Feb 2026
        self.clinics = [
            {
                "name": "Psychiatry-UK",
                "wait_time": "8-10 Months",
                "titration_wait": "7-10 Months",
                "status": "Open",
                "notes": "Largest provider, uses online portal."
            },
            {
                "name": "ADHD 360",
                "wait_time": "Paused",
                "titration_wait": "N/A",
                "status": "Paused",
                "notes": "Reviewing capacity April 2026."
            },
            {
                "name": "Clinical Partners",
                "wait_time": "12-18 Months",
                "titration_wait": "12-18 Months",
                "status": "Open",
                "notes": "Good for complex cases/children."
            },
            {
                "name": "Dr J & Colleagues",
                "wait_time": "6-9 Months",
                "titration_wait": "3-6 Months",
                "status": "Open",
                "notes": "Smaller provider, often faster titration."
            },
            {
                "name": "Psicon",
                "wait_time": "9-12 Months",
                "titration_wait": "Unknown",
                "status": "Restricted",
                "notes": "Paused in some local areas."
            }
        ]

    def display_clinics(self):
        console.print(Panel("[bold magenta]Right to Choose (RTC) Clinic Comparison[/bold magenta]\n"
                            "Wait times are estimates based on national data. "
                            "Always check the provider's website before requesting a referral."))
        
        table = Table(title="UK ADHD RTC Providers (Feb 2026)")
        table.add_column("Clinic Name", style="bold cyan")
        table.add_column("Assessment Wait", style="yellow")
        table.add_column("Titration Wait", style="yellow")
        table.add_column("Status", style="bold")
        table.add_column("Key Info")
        
        for clinic in self.clinics:
            status_style = "green" if clinic["status"] == "Open" else "red" if clinic["status"] == "Paused" else "yellow"
            table.add_row(
                clinic["name"],
                clinic["wait_time"],
                clinic["titration_wait"],
                f"[{status_style}]{clinic['status']}[/{status_style}]",
                clinic["notes"]
            )
        
        console.print(table)
        console.print("\n[bold]How to use this:[/bold] Pick a clinic with 'Open' status and a wait time that works for you. "
                      "Ask your GP for a 'Right to Choose' referral to that specific provider.")

if __name__ == "__main__":
    manager = ClinicManager()
    manager.display_clinics()
