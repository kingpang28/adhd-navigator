# ADHD Pre-Referral Navigator Research Findings

## 1. Clinical Guidelines (NICE/WHO)
- **Diagnosis Requirements**: Diagnosis must be made by a specialist psychiatrist, paediatrician, or other healthcare professional with training and expertise in ADHD.
- **Adult Screening (ASRS v1.1)**:
  - Part A (6 questions) is the most predictive.
  - Scoring: 4 or more marks in the shaded boxes of Part A indicates symptoms highly consistent with adult ADHD.
  - Part B (12 questions) provides additional clinical information.
- **Child Screening (SNAP-IV or similar)**: Usually requires parent and teacher input.
- **Vitals Monitoring**:
  - Pre-medication baseline: Heart Rate (HR) and Blood Pressure (BP) are essential.
  - Ongoing monitoring: Required at every titration step and then every 6 months.

## 2. Right to Choose (RTC) Providers & Wait Times (Approx. Feb 2026)

| Provider | Assessment Wait Time | Titration/Medication Wait Time | Notes |
| :--- | :--- | :--- | :--- |
| **Psychiatry-UK** | 8 - 10 months (32-40 weeks) | 7 - 10 months | Largest provider; portal-based system. |
| **ADHD 360** | Paused (Review April 2026) | N/A | RTC referrals currently on hold in many areas. |
| **Clinical Partners** | 12 - 18 months | 12 - 18 months | Covers both adults and children. |
| **Psicon** | ~9 months | Unknown | Paused in some ICB areas until April 2026. |
| **Dr J & Colleagues** | ~6 - 9 months | ~3 - 6 months | Smaller provider, often shorter titration waits. |

## 3. Right to Choose Process
1. **Identify Provider**: Choose a provider that holds an NHS contract.
2. **GP Consultation**: Discuss symptoms and request referral under "Right to Choose" (England only).
3. **Referral Pack**: Most providers have a specific "GP Referral Letter" and "Patient Questionnaire" to be completed.

## 4. Application Logic
- **Screening**: Implement ASRS v1.1 with logic-based results (Low/Medium/High likelihood).
- **Vitals**: Input fields for Systolic BP, Diastolic BP, and Pulse. Compare against healthy ranges (e.g., BP < 140/90).
- **Clinic Comparison**: Sortable list of providers by wait time and status.
- **Medication Readiness**: Flag if vitals are missing or outside "safe" range for starting stimulants.
